// Copyright © 2014 
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions: The above copyright
// notice and this permission notice shall be included in all copies or
// substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

import UIKit

class WorkSpace: CanvasController {
    lazy var dx: Double = 0.0
    lazy var dy: Double = 0.0
    lazy var ox: Double = 0.0
    lazy var oy: Double = 0.0
    lazy var c: Color = lightGray

    override func viewDidLoad() {
        dx = 5.0
        dy = dx / 1.9
        ox = Double(canvas.frame.size.width) / 2.0
        oy = 10.0

        createGrid()
        createLogo()
    }

    func createGrid() {
        for x in 0...100 {
            for y in 0...100 {
                let p = convertCoordinate(Point(x,y))
                if canvas.frame.contains(p) {
                    let e = createPoint(p)
                    self.canvas.add(e)
                }
            }
        }
    }

    func createLogo() {
        c = blue
        ln(0, 10, 0, 20)
        ln(0, 20, 16, 36)
        ln(0, 10, 2, 12)
        ln(2,12,2,22)
        ln(2,12,12,12)
        ln(4,10,6,12)
        ln(0,10,10,10)
        ln(8,8,10,8)
        ln(8,8,8,10)
        ln(10,10,10,8)
        ln(10,8,18,16)
        ln(10,10,22,22)
        ln(4, 22, 4, 12)
        ln(4,22,16,34)
        ln(16,34,24,34)
        ln(24,34,26,36)
        ln(26,36,16,36)
        ln(26,36,26,26)
        ln(26,34,24,32)
        ln(24,32,24,24)
        ln(24,24,24,16)
        ln(24,32,16,32)
        ln(16,32,6,22)
        ln(6,22,6,12)
        ln(6,20,16,30)
        ln(16,30,20,30)
        ln(20,30,20,24)
        ln(20,24,12,16)
        ln(12,16,6,16)
        ln(6,14,12,14)
        ln(12,14,24,26)
        ln(12,14,12,16)
        ln(14,18,12,18)
        ln(12,18,10,16)
        ln(22,32,22,26)
        ln(22,26,24,26)
        ln(20,24,22,26)
        ln(22,22,22,14)
        ln(22,14,10,2)
        ln(26,26,24,24)
        ln(24,18,32,26)
        ln(32,26,32,24)
        ln(32,24,24,16)
        ln(22,14,20,14)
        ln(20,14,20,18)
        ln(20,18,18,16)
        ln(18,16,18,12)
        ln(20,14,10,4)
        ln(10,4,10,0)
        ln(10,0,12,0)
        ln(12,0,20,8)
        ln(20,6,22,8)
        ln(20,6,20,8)
        ln(18,6,20,6)
        ln(22,8,22,10)
        ln(22,10,34,22)
        ln(34,22,34,26)
        ln(34,26,32,26)
        ln(34,24,12,2)
        ln(12,2,10,2)
        ln(12,30,14,30)

        var points = [Point]()
        points.append(convertCoordinate(Point(3,0)))
        points.append(convertCoordinate(Point(3,1)))
        points.append(convertCoordinate(Point(4,2)))
        points.append(convertCoordinate(Point(5,2)))
        points.append(convertCoordinate(Point(5,1)))
        points.append(convertCoordinate(Point(4,0)))
        points.append(convertCoordinate(Point(3,0)))
    }

    func ln(x1: Int, _ y1: Int, _ x2: Int, _ y2: Int) {
        let a = convertCoordinate(Point(x1,y1))
        let b = convertCoordinate(Point(x2,y2))
        let l = Line([a,b])
        l.lineCap = .Round
        l.strokeColor = c
        l.lineWidth = 2.0
        canvas.add(l)
    }

    func pt(x: Int, _ y: Int) {
        let p = convertCoordinate(Point(x,y))
        let e = createEllipse(p)
        e.fillColor = c
        canvas.add(e)
    }

    func convertCoordinate(point: Point) -> Point {
        return Point(point.x * dx + ox - dx * point.y, point.y * dy + oy + dy * point.x)
    }

    func createEllipse(point: Point) -> Ellipse {
        let e = Ellipse(frame: Rect(0,0,8,8))
        e.center = point
        

        e.strokeColor = red
        e.lineWidth = 1.0
        e.fillColor = clear
        return e
    }

    func createPoint(point: Point) -> Ellipse {
        let e = Ellipse(frame: Rect(0,0,1,1))
        e.fillColor = c
        e.strokeColor = clear
        e.center = point
        return e
    }
}