// Copyright © 2016
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions: The above copyright
// notice and this permission notice shall be included in all copies or
// substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

import UIKit

class WorkSpace: CanvasController {
    override func setup() {
        array2D()
    }

    func array2D() {
        let maxDistance = distance(Point(), rhs: canvas.center)
        canvas.backgroundColor = black
        var pt = Point(8, 8)

        repeat {
            repeat {
                let c = Circle(center: pt, radius: 3)
                let d = distance(pt, rhs: canvas.center) / maxDistance
                c.lineWidth = 0.0
                c.fillColor = Color(red: d, green: d, blue: d, alpha: 1.0)
                canvas.add(c)
                pt.x += 10.0
            } while pt.x < canvas.width
            pt.y += 10.0
            pt.x = 8.0
        } while pt.y < canvas.height
    }

    func pieChart() {
        let angles: [Double] = [30.0, 10, 45, 35, 60, 38, 75, 67]
        var pΘ = 0.0
        for i in 0..<angles.count {
            let c = map(Double(i), min: 0, max: Double(angles.count), toMin: 0, toMax: 1)
            let Θ = degToRad(angles[i])
            let a = Wedge(center: canvas.center, radius: 150, start: pΘ, end: pΘ+Θ)
            a.fillColor = Color(red: c, green: c, blue: c, alpha: 1.0)
            a.lineWidth = 0.0
            pΘ += Θ
            canvas.add(a)
        }
    }

    func pan() {
        let rect = Rectangle(frame: Rect(0,0,100,100))
        rect.center = canvas.center
        rect.strokeColor = clear
        canvas.add(rect)

        var center = Point()
        let press = rect.addLongPressGestureRecognizer { (location, state) -> () in
            switch state {
            case .Began:
                ShapeLayer.disableActions = true
                rect.strokeColor = C4Pink
                center = location
            case .Changed:
                let dxdy = Vector(location) - Vector(center)
                rect.center += dxdy
            case .Ended:
                rect.strokeColor = clear
            default:
                _ = ""
            }
        }
        press.minimumPressDuration = 0.0
    }

    func storingInput() {
        canvas.addPanGestureRecognizer { location, translation, velocity, state in
            ShapeLayer.disableActions = true
            let circle = Circle(center: location, radius: 30)
            self.canvas.add(circle)
            ShapeLayer.disableActions = false

            let a = ViewAnimation(duration: 1.0) {
                circle.opacity = 0.0
                circle.transform.scale(0.01, 0.01)
            }
            a.addCompletionObserver {
                circle.removeFromSuperview()
            }
            a.curve = .Linear
            a.animate()
        }
    }

    func continuousLines() {
        let p = Path()
        let poly = Polygon()
        canvas.add(poly)
        canvas.addPanGestureRecognizer { location, translation, velocity, state in
            if state == .Began {
                p.moveToPoint(location)
            } else {
                p.addLineToPoint(location)
            }
            poly.path = p
        }
    }

    func pattern() {
        var circles = [Circle()]
        canvas.addPanGestureRecognizer { (location, translation, velocity, state) -> () in
            let c = Circle(center: location, radius: abs(velocity.x/50.0))
            c.lineWidth = abs(velocity.y/100.0)
            self.canvas.add(c)
            circles.append(c)
            if circles.count > 100 {
                circles[0].removeFromSuperview()
                circles.removeAtIndex(0)
            }
        }
    }

    func animateBackground() {
        let a = ViewAnimation(duration: 4.0) {
            self.canvas.backgroundColor = black
        }
        a.repeats = true
        a.autoreverses = true
        a.animate()
    }

    func vectorMath() {
        let line = Line((Point(),Point(100,0)))
        line.opacity = 0.25
        line.anchorPoint = Point(0,0)
        line.lineWidth = 20
        line.center = canvas.center
        canvas.add(line)

        let vc = Vector(canvas.center)
        canvas.addPanGestureRecognizer { location, translation, velocity, state in
            let vl = Vector(location)
            let Θ = (vl-vc).heading

            ShapeLayer.disableActions = true
            line.rotation = Θ
        }
    }

    func follow1() {
        let circle = Circle(center: Point(0,0), radius: 10)
        circle.strokeColor = C4Purple.colorWithAlpha(0.25)
        circle.lineWidth = 20.0

        let line = Line((Point(),Point(100,0)))
        line.opacity = 0.25
        line.anchorPoint = Point(0,0)
        line.lineWidth = 20
        line.center = circle.bounds.center

        circle.add(line)
        canvas.add(circle)

        var v = Vector()
        canvas.addPanGestureRecognizer { location, translation, velocity, state in
            let vl = Vector(location)
            let dxdy = vl-v
            let Θ = dxdy.heading

            v = vl - Vector(x: cos(Θ) * 100, y: sin(Θ) * 100)

            ShapeLayer.disableActions = true
            circle.center = Point(v.x, v.y)
            line.rotation = Θ
        }
    }
}

