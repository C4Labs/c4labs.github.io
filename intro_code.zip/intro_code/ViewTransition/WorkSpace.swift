// Copyright © 2016
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions: The above copyright
// notice and this permission notice shall be included in all copies or
// substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

import UIKit

class WorkSpace: CanvasController {
    var b = true

    override func setup() {
        //noContainer()
        container()
    }

    func noContainer() {
        let v1 = View(frame: Rect(0,0,100,100))
        v1.backgroundColor = blue

        let v2 = View(frame:v1.frame)
        v2.backgroundColor = red
        v2.hidden = true

        canvas.add(v1)
        canvas.add(v2)

        canvas.addTapGestureRecognizer { (location, state) -> () in
            var from = v1
            var to = v2
            var options = UIViewAnimationOptions.BeginFromCurrentState
            if self.b {
                options.insert(UIViewAnimationOptions.TransitionFlipFromLeft)
            }
            else {
                from = v2
                to = v1
                options.insert(UIViewAnimationOptions.TransitionFlipFromRight)
            }
            from.hidden = true
            to.hidden = false
            UIView.transitionFromView(from.view, toView: to.view, duration: 0.25, options: UIViewAnimationOptions.TransitionFlipFromRight, completion: nil)

            self.b = !self.b
        }

    }

    func container() {
        let c = View(frame: Rect(0,0,100,100))
        let v1 = View(frame: c.frame)
        v1.backgroundColor = blue

        let v2 = View(frame:c.frame)
        v2.backgroundColor = red
        v2.hidden = true

        c.add(v1)
        c.add(v2)
        canvas.add(c)

        canvas.addTapGestureRecognizer { (location, state) -> () in
            var from = v1
            var to = v2
            var options = UIViewAnimationOptions.BeginFromCurrentState
            if self.b {
                options.insert(UIViewAnimationOptions.TransitionFlipFromLeft)
            }
            else {
                from = v2
                to = v1
                options.insert(UIViewAnimationOptions.TransitionFlipFromRight)
            }
            from.hidden = true
            to.hidden = false
            UIView.transitionFromView(from.view, toView: to.view, duration: 0.25, options: UIViewAnimationOptions.TransitionFlipFromRight, completion: nil)
            
            self.b = !self.b
        }
    }
}
