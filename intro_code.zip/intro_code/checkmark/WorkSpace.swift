// Copyright © 2014 
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions: The above copyright
// notice and this permission notice shall be included in all copies or
// substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

import UIKit

class WorkSpace: CanvasController {
    var b1: Shape!
    var b2: Shape!
    var b3: Shape!

    var b1ToX: ViewAnimation!
    var b1ToCheck: ViewAnimation!

    var b2ToX: ViewAnimation!
    var b2ToCheck: ViewAnimation!

    var b3ToX: ViewAnimation!
    var b3ToCheck: ViewAnimation!

    var x = false

    let d = 0.5
    let dc = 0.25
    override func setup() {
        canvas.backgroundColor = C4Purple

        b1 = createBezier1()
        b2 = createBezier2()
        b3 = createBezier3()

        b1.center = canvas.center
        b1.add(b2)
        b1.add(b3)
        canvas.add(b1)

        createB1Animations()
        createB2Animations()
        createB3Animations()

        canvas.addTapGestureRecognizer { location, state in
            if self.x {
                self.toCheck()
                self.animate(C4Blue)
            } else {
                self.toX()
                self.animate(C4Pink)
            }
            self.x = !self.x
        }
    }

    func animate(color: Color) {
        ViewAnimation(duration: d + dc) {
            self.b1.strokeColor = color
            self.b2.strokeColor = color
            self.b3.strokeColor = color
            }.animate()
    }

    func createB1Animations() {
        b1ToX = ViewAnimation(duration: d) {
            self.b1.strokeStart = 0.6
        }
        b1ToX.curve = .EaseIn

        b1ToX.addCompletionObserver { () -> Void in
            let a = ViewAnimation(duration: self.dc) {
                self.b1.strokeStart = 0.88
                self.b1.strokeEnd = 1.0
            }
            a.curve = .EaseOut
            a.animate()
        }

        b1ToCheck = ViewAnimation(duration: d) {
            self.b1.strokeStart = 0.6
            self.b1.strokeEnd = 0.81
        }
        b1ToCheck.curve = .EaseIn
        b1ToCheck.addCompletionObserver { () -> Void in
            let a = ViewAnimation(duration: self.dc) {
                self.b1.strokeStart = 0.0
            }
            a.curve = .EaseOut
            a.animate()
        }

    }

    func createB2Animations() {
        b2ToX = ViewAnimation(duration: d) {
            self.b2.strokeStart = 0.15
            self.b2.strokeEnd = 0.21
        }
        b2ToX.curve = .EaseIn
        b2ToX.addCompletionObserver { () -> Void in
            let a = ViewAnimation(duration: self.dc) {
                self.b2.strokeEnd = 1.0
            }
            a.curve = .EaseOut
            a.animate()
        }

        b2ToCheck = ViewAnimation(duration: d) {
            self.b2.strokeEnd = 0.21
        }
        b2ToCheck.curve = .EaseIn
        b2ToCheck.addCompletionObserver { () -> Void in
            let a = ViewAnimation(duration: self.dc) {
                self.b2.strokeStart = 0.0
                self.b2.strokeEnd = 0.06
            }
            a.curve = .EaseOut
            a.animate()
        }
    }

    func createB3Animations() {
        b3ToX = ViewAnimation(duration: d) {
            self.b3.strokeStart = 0.0
            self.b3.strokeEnd = 0.19
        }

        b3ToCheck = ViewAnimation(duration: d) {
            self.b3.strokeStart = 0.804
            self.b3.strokeEnd = 1.0
        }
    }

    func toX() {
        b1ToX.animate()
        wait(0.15) {
            self.b3ToX.animate()
        }
        wait(0.3) {
            self.b2ToX.animate()
        }
    }

    func toCheck() {
        b2ToCheck.animate()
        wait(0.5) {
            self.b3ToCheck.animate()
            self.b1ToCheck.animate()
        }
    }

    func createBezier1() -> Shape {
        let bezier = UIBezierPath()
        bezier.moveToPoint(CGPointMake(177.2, 30.4))
        bezier.addCurveToPoint(CGPointMake(103.8, 0), controlPoint1: CGPointMake(158.4, 11.6), controlPoint2: CGPointMake(132.5, 0))
        bezier.addCurveToPoint(CGPointMake(0, 103.8), controlPoint1: CGPointMake(46.5, 0), controlPoint2: CGPointMake(0, 46.5))
        bezier.addCurveToPoint(CGPointMake(103.8, 207.6), controlPoint1: CGPointMake(0, 161.1), controlPoint2: CGPointMake(46.5, 207.6))
        bezier.addCurveToPoint(CGPointMake(207.6, 103.8), controlPoint1: CGPointMake(161.1, 207.6), controlPoint2: CGPointMake(207.6, 161.1))
        bezier.addCurveToPoint(CGPointMake(177.2, 30.4), controlPoint1: CGPointMake(207.6, 75.1), controlPoint2: CGPointMake(196, 49.2))
        bezier.addLineToPoint(CGPointMake(69.2, 138.4))

        let path = Path(path: bezier.CGPath)
        let shape = Shape(path)
        shape.fillColor = clear
        shape.lineWidth = 2.0
        shape.strokeStart = 0.0
        shape.strokeEnd = 0.81
        shape.strokeColor = C4Blue
        return shape
    }

    func createBezier2() -> Shape {
        let bezier = UIBezierPath()
        bezier.moveToPoint(CGPointMake(90.9, 138.4))
        bezier.addLineToPoint(CGPointMake(10.6, 58.1))
        bezier.addCurveToPoint(CGPointMake(0, 103.8), controlPoint1: CGPointMake(3.8, 71.9), controlPoint2: CGPointMake(0, 87.4))
        bezier.addCurveToPoint(CGPointMake(103.8, 207.6), controlPoint1: CGPointMake(0, 161.1), controlPoint2: CGPointMake(46.5, 207.6))
        bezier.addCurveToPoint(CGPointMake(207.7, 103.8), controlPoint1: CGPointMake(161.1, 207.6), controlPoint2: CGPointMake(207.7, 161.1))
        bezier.addCurveToPoint(CGPointMake(103.9, 0), controlPoint1: CGPointMake(207.7, 46.5), controlPoint2: CGPointMake(161.3, 0))
        bezier.addCurveToPoint(CGPointMake(10.7, 58.1), controlPoint1: CGPointMake(63, 0), controlPoint2: CGPointMake(27.6, 23.7))

        let path = Path(path: bezier.CGPath)
        let shape = Shape(path)
        shape.fillColor = clear
        shape.lineWidth = 2.0
        shape.strokeStart = 0.0
        shape.strokeEnd = 0.06
        shape.strokeColor = C4Blue
        return shape
    }

    func createBezier3() -> Shape {
        let bezier = UIBezierPath()
        bezier.moveToPoint(CGPointMake(138.4, 138.4))
        bezier.addLineToPoint(CGPointMake(30.4, 30.4))
        bezier.addCurveToPoint(CGPointMake(0, 103.8), controlPoint1: CGPointMake(11.6, 49.2), controlPoint2: CGPointMake(0, 75.1))
        bezier.addCurveToPoint(CGPointMake(42, 187.2), controlPoint1: CGPointMake(0, 138), controlPoint2: CGPointMake(16.5, 168.3))
        bezier.addLineToPoint(CGPointMake(160, 69.2))

        let path = Path(path: bezier.CGPath)
        let shape = Shape(path)
        shape.fillColor = clear
        shape.lineWidth = 2.0
        shape.strokeStart = 0.804
        shape.strokeEnd = 1.0
        shape.strokeColor = C4Blue
        return shape
    }
}
