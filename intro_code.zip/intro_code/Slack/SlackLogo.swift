// Copyright © 2014 C4
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions: The above copyright
// notice and this permission notice shall be included in all copies or
// substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

import UIKit

class SlackLogo: View {
    var slackGreen = Color(red: 0.31, green: 0.76, blue: 0.61, alpha: 1.0)
    var slackBlue = Color(red: 0.51, green: 0.80, blue: 0.85, alpha: 1.0)
    var slackYellow = Color(red: 0.91, green: 0.70, blue: 0.21, alpha: 1.0)
    var slackPink = Color(red: 0.87, green: 0.10, blue: 0.42, alpha: 1.0)

    var slackGreenOverlay = Color(red: 0.18, green: 0.62, blue: 0.53, alpha: 1.0)
    var slackBlueOverlay = Color(red: 0.47, green: 0.58, blue: 0.16, alpha: 1.0)
    var slackYellowOverlay = Color(red: 0.81, green: 0.05, blue: 0.11, alpha: 1.0)
    var slackPinkOverlay = Color(red: 0.24, green: 0.03, blue: 0.24, alpha: 1.0)

    var positions = [Point(53.0, 30.0),Point(76.0, 53.0),Point(53.0, 76.0),Point(30.0, 53.0)]

    var slackLines = [SlackLine]()
    
    var isSquares = false {
        didSet {
            for slackline in self.slackLines {
                slackline.isSquares = isSquares
            }
        }
    }
    
    override init() {
        super.init()
        frame = Rect(0,0,106,106)

        var colors = [slackGreen, slackBlue, slackYellow, slackPink]
        var smallSquareColors = [slackGreenOverlay, slackBlueOverlay, slackYellowOverlay, slackPinkOverlay]

        for i in 0...3 {
            let slackline = SlackLine()
            slackline.center = positions[i]
            slackline.strokeColor = colors[i]
            slackline.squareColor = smallSquareColors[i]

            let dir = i % 2 == 0 ? 1.0 : -1.0
            slackline.transform = Transform.makeRotation(dir * Double(i) * M_PI/2)

            slackLines.append(slackline)
            add(slackline)
        }

        rotation = -M_PI/10.0
    }
    
    func animate() {
        ViewAnimation(duration:0.85) {
            self.rotation += M_PI * 2
        }.animate()

        for line in slackLines {
            line.animate()
        }
    }
}