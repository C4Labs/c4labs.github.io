// Copyright © 2014 C4
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions: The above copyright
// notice and this permission notice shall be included in all copies or
// substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

var squareCenterOffset = 30.0

import UIKit

class SlackLine: View {
    var isSquares = false {
        didSet {
            line.hidden = isSquares
            square.hidden = !isSquares
        }
    }
    
    var strokeColor: Color = C4Blue {
        didSet {
            line.strokeColor = strokeColor
        }
    }
    var squareColor: Color = C4Pink {
        didSet {
            square.fillColor = squareColor
        }
    }

    var line: Line!
    var square: Rectangle!
    var squareMask: Line!
    
    override init() {
        super.init()
        self.frame = Rect(0,0,106,18.0)

        let squareCenterOffset = width - 30.0

        square = Rectangle(frame: Rect(squareCenterOffset-height/2.0,0,height,height))
        line = Line(Point(height/2.0,height/2.0),Point(width-height/2.0,height/2.0))

        let maskXOffset = square.origin.x - line.points[0].x
        squareMask = Line(Point(-maskXOffset,height/2.0),Point(line.points[1].x-line.points[0].x-maskXOffset,height/2.0))


        line.lineWidth = height
        add(line)
        
        square.corner = Size()
        square.lineWidth = 0
        square.hidden = true
        add(square)

        squareMask.lineWidth = height
        square.mask = squareMask

        var anchor = square.center
        anchor.x += height * 0.26
        anchor.x /= width
        anchor.y = 0.5
        squareMask.anchorPoint = anchor

    }
    
    func animate() {
        let strokeOut = ViewAnimation(duration: 0.25) {
            self.line.strokeEnd = 0.01
            self.squareMask.strokeEnd = 0.01
        }
        strokeOut.curve = .EaseOut
        strokeOut.delay = 0.1

        let rotateMask = ViewAnimation(duration: 0) {
            self.square.hidden = true
            self.squareMask.transform = Transform.makeRotation(M_PI/2)
        }

        let shiftStroke = ViewAnimation(duration: 0.25) {
            self.line.strokeStart = 0.99
            self.line.strokeEnd = 1.0
        }
        shiftStroke.delay = 0.35
        shiftStroke.curve = .EaseIn

        let revealSquare = ViewAnimation(duration: 0) {
            self.square.hidden = false
        }

        let strokeIn = ViewAnimation(duration: 0.15) {
            self.line.lineWidth -= 1
            self.line.strokeStart = 0.05
            self.squareMask.strokeEnd = 0.95
            self.line.transform.scale(1/1.05, 1.0)
        }
        strokeIn.delay = 0.2

        let bounceOut = ViewAnimation(duration: 0.15) {
            self.line.transform.scale(1.05, 1.0)
            self.line.lineWidth += 1
            self.line.strokeStart = 0.0
            self.squareMask.strokeEnd = 1.0
        }

        let revertMaskRotation = ViewAnimation(duration: 0) {
            self.squareMask.transform = Transform()
        }

        let seq = ViewAnimationSequence(animations: [strokeOut, rotateMask, shiftStroke, revealSquare, strokeIn, bounceOut, revertMaskRotation])
        seq.animate()
    }
}
