// Copyright © 2015 C4
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions: The above copyright
// notice and this permission notice shall be included in all copies or
// substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.

import UIKit

class WorkSpace: C4CanvasController {

    override func setup() {
        line()
    }
    
    func sequenceAnimation() {
        let square = C4Rectangle(frame: C4Rect(0,0,100,100))
        square.center = canvas.center
        canvas.add(square)
        
        let circle = C4Circle(center: canvas.center, radius: 50)
        canvas.add(circle)
        
        let squareAnim = C4ViewAnimation(duration: 1.0) { () -> Void in
            square.transform = C4Transform.makeRotation(M_PI)
        }
        
        let circleAnim = C4ViewAnimation(duration: 1.0) { () -> Void in
            let randomColor = C4Color(red: random01(), green: random01(), blue: random01(), alpha: 1.0)
            circle.fillColor = randomColor
        }
        
        let sequence = C4ViewAnimationSequence(animations: [squareAnim, circleAnim])
        
        delay(1.0) { () -> () in
            sequence.animate()
        }
    }
    
    func groupAnimation() {
        let square = C4Rectangle(frame: C4Rect(0,0,100,100))
        square.center = canvas.center
        canvas.add(square)
        
        let circle = C4Circle(center: canvas.center, radius: 50)
        canvas.add(circle)
        
        let squareAnim = C4ViewAnimation(duration: 1.0) { () -> Void in
            square.transform = C4Transform.makeRotation(M_PI)
        }
        
        let circleAnim = C4ViewAnimation(duration: 1.0) { () -> Void in
            let randomColor = C4Color(red: random01(), green: random01(), blue: random01(), alpha: 1.0)
            circle.fillColor = randomColor
        }
        
        let group = C4ViewAnimationGroup(animations: [squareAnim, circleAnim])
        
        delay(1.0) { () -> () in
            group.animate()
        }
    }

    func propertyAnimation() {
        let anim = C4ViewAnimation(duration: 1.0) { () -> Void in
            self.canvas.backgroundColor = C4Blue
        }
        
        anim.curve = .EaseOut
        anim.repeats = true
        
        delay(1.0) {
            anim.animate()
        }
    }
    
    func panGesture() {
        let square = C4Rectangle(frame: C4Rect(0,0,100,100))
        square.center = canvas.center
        canvas.add(square)
        
        canvas.addPanGestureRecognizer { (location, translation, velocity, state) -> () in
            square.center = location
        }
    }
    
    func tapGesture() {
        let square = C4Rectangle(frame: C4Rect(0,0,100,100))
        square.center = canvas.center
        canvas.add(square)
        
        square.addTapGestureRecognizer { location, state in
            let randomColor = C4Color(red: random01(), green: random01(), blue: random01(), alpha: 1.0)
            self.canvas.backgroundColor = randomColor
        }
    }

    let player = C4AudioPlayer("loop.aif")
    func audioPlayer() {
        player?.loops = true
        player?.play()
    }

    func generator() {
        let image = C4Image(frame: C4Rect(0,0,100,100))
        
        let checkerBoard = C4Checkerboard()
        image.generate(checkerBoard)
        image.center = canvas.center
        canvas.add(image)
    }
    
    func movie() {
        let movie = C4Movie("halo.mp4")
        movie?.center = canvas.center
        canvas.add(movie)
        movie?.play()
    }
    
    func filter() {
        let image = C4Image("chop")
        image?.center = canvas.center
        canvas.add(image)
        
        var dotScreen = C4DotScreen()
        dotScreen.width = 10.0
        image?.apply(dotScreen)
    }
    
    func image() {
        let image = C4Image("chop")
        image?.center = canvas.center
        canvas.add(image)
    }
    
    func patternImages() {
        let r = C4Rectangle(frame: C4Rect(0,0,96,96))
        r.center = canvas.center
        r.fillColor = C4Color("pattern1")
        r.lineWidth = 8.0
        r.strokeColor = C4Color("pattern2")
        canvas.add(r)
    }
    
    func colorsCustmo() {
        canvas.backgroundColor = C4Color(red: 0.25, green: 0.5, blue: 0.75, alpha: 1.0)
    }
    
    func colorsDefault() {
        let r = C4Rectangle(frame: C4Rect(0,0,100,100))
        r.center = canvas.center
        r.lineWidth = 8
        r.strokeColor =  green
        r.fillColor = blue
        canvas.add(r)
        canvas.backgroundColor = red
    }
    
    func colorsC4() {
        let r = C4Rectangle(frame: C4Rect(0,0,100,100))
        r.center = canvas.center
        r.lineWidth = 8
        r.strokeColor = C4Blue
        r.fillColor = C4Pink
        canvas.add(r)
        canvas.backgroundColor = C4Purple
    }
    
    func textShape() {
        let string = "C4"
        let textShape = C4TextShape(text: string)!
        textShape.center = canvas.center
        canvas.add(textShape)
    }
    
    func wedge() {
        let wedge = C4Wedge(center: canvas.center, radius: 50, start: 1.25 * M_PI, end: 1.75 * M_PI)
        canvas.add(wedge)
    }
    
    func arc() {
        let arc = C4Arc(center: canvas.center, radius: 50, start: M_PI, end: 2 * M_PI)
        canvas.add(arc)
    }
    
    func polygon() {
        let points = [C4Point(),C4Point(100,100),C4Point(200,0), C4Point(300,100)]
        let polygon = C4Polygon(points)
        polygon.center = canvas.center
        canvas.add(polygon)
    }
    
    func triangle() {
        let points = [C4Point(),C4Point(100,100),C4Point(200,0)]
        let triangle = C4Triangle(points)
        triangle.center = canvas.center
        canvas.add(triangle)
    }
    
    func ellipse() {
        let ellipse = C4Ellipse(frame: C4Rect(0,0,200,100))
        ellipse.center = canvas.center
        canvas.add(ellipse)
    }
    
    func circle() {
        let circle = C4Circle(center: canvas.center, radius: 50)
        canvas.add(circle)
    }
    
    func square() {
        let square = C4Rectangle(frame: C4Rect(0,0,100,100))
        square.center = canvas.center
        canvas.add(square)
    }
    
    func line() {
        let points = (C4Point(),C4Point(100,100))
        let line = C4Line(points)
        line.center = canvas.center
        canvas.add(line)
    }
}

